# -*- coding: utf-8 -*-
"""
MaixCAM2 人脸识别智能系统 - 视频合成与播放管理模块

功能：
- 将同名 MP4 视频和 WAV 音频合成为带音频 MP4
- 使用 MaixPy video.Decoder + audio.Player 播放带音频视频
- 保留原始录制文件，合成产物使用 _av.mp4 后缀
"""

from maix import video, audio, time, app, image
import os


class VideoPlayerManager:
    """视频播放器管理器"""

    def __init__(self, disp, record_dir, volume=80):
        """
        初始化视频播放器

        参数：
            disp: MaixPy 显示对象
            record_dir: 录像文件目录
            volume: 播放音量
        """
        self._disp = disp
        self._record_dir = record_dir
        self._volume = volume
        self._ensure_dir(record_dir)
        print(f"[播放器] 初始化完成，目录: {record_dir}")

    def _ensure_dir(self, dir_path):
        """确保目录存在"""
        try:
            os.makedirs(dir_path, exist_ok=True)
        except Exception as e:
            print(f"[播放器] 创建目录失败: {e}")

    def get_muxed_path(self, video_path):
        """获取合成后的视频路径"""
        if not video_path:
            return ""
        base, ext = os.path.splitext(video_path)
        if base.endswith("_av"):
            return video_path
        return f"{base}_av{ext or '.mp4'}"

    def find_audio_path(self, video_path):
        """查找与视频同名的 WAV 音频文件"""
        if not video_path:
            return ""
        base, _ = os.path.splitext(video_path)
        audio_path = base + ".wav"
        if os.path.exists(audio_path) and os.path.getsize(audio_path) > 44:
            return audio_path
        return ""

    def list_video_items(self):
        """
        读取录像目录中的原始视频和已融合视频

        返回：
            录像信息列表，每项包含原始 MP4、WAV、融合 MP4 的路径和大小
        """
        items = []
        try:
            if not os.path.exists(self._record_dir):
                return items

            for name in os.listdir(self._record_dir):
                if (not name.endswith(".mp4")) or name.endswith("_av.mp4"):
                    continue

                video_path = os.path.join(self._record_dir, name)
                base = name[:-4]
                audio_name = base + ".wav"
                av_name = base + "_av.mp4"
                audio_path = os.path.join(self._record_dir, audio_name)
                av_path = os.path.join(self._record_dir, av_name)
                audio_size = os.path.getsize(audio_path) if os.path.exists(audio_path) else 0
                av_size = os.path.getsize(av_path) if os.path.exists(av_path) else 0

                items.append({
                    "name": name,
                    "video_path": video_path,
                    "video_size": os.path.getsize(video_path),
                    "audio_name": audio_name if audio_size > 44 else "",
                    "audio_path": audio_path if audio_size > 44 else "",
                    "audio_size": audio_size if audio_size > 44 else 0,
                    "av_name": av_name if av_size > 0 else "",
                    "av_path": av_path if av_size > 0 else "",
                    "av_size": av_size,
                })

            items.sort(key=lambda item: item.get("name", ""), reverse=True)
        except Exception as e:
            print(f"[播放器] 读取录像列表失败: {e}")
        return items

    def count_muxed(self):
        """统计已融合视频数量"""
        count = 0
        for item in self.list_video_items():
            if item.get("av_size", 0) > 0:
                count += 1
        return count

    def mux_all(self):
        """
        批量融合所有已有 MP4/WAV 文件

        返回：
            (成功数量, 总数量)
        """
        success_count = 0
        total_count = 0
        for item in self.list_video_items():
            if not item.get("audio_path"):
                continue
            total_count += 1
            output_path = self.mux(item.get("video_path", ""), item.get("audio_path", ""))
            if output_path and output_path.endswith("_av.mp4") and os.path.exists(output_path):
                success_count += 1
        print(f"[播放器] 批量融合完成: {success_count}/{total_count}")
        return success_count, total_count

    def mux(self, video_path, audio_path=""):
        """
        合成 MP4 + WAV 为带音频 MP4

        返回：
            合成后视频路径；失败时返回原视频路径或空字符串
        """
        if not video_path or not os.path.exists(video_path):
            print(f"[播放器] 视频不存在: {video_path}")
            return ""

        if video_path.endswith("_av.mp4"):
            return video_path

        if not audio_path:
            audio_path = self.find_audio_path(video_path)
        if not audio_path:
            print("[播放器] 未找到有效 WAV，使用原视频播放")
            return video_path

        output_path = self.get_muxed_path(video_path)
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            return output_path

        cmd = (
            "ffmpeg -y -i \"{}\" -i \"{}\" "
            "-c:v copy -c:a aac -b:a 96k -shortest \"{}\""
        ).format(video_path, audio_path, output_path)
        print(f"[播放器] 开始合成: {output_path}")
        ret = os.system(cmd)
        if ret == 0 and os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            print(f"[播放器] 合成完成: {output_path}")
            return output_path

        print(f"[播放器] 合成失败，返回码: {ret}")
        return video_path

    def play(self, video_path):
        """
        播放视频文件

        参数：
            video_path: MP4 文件路径

        返回：
            True: 播放完成
            False: 播放失败
        """
        if not video_path or not os.path.exists(video_path):
            print(f"[播放器] 播放文件不存在: {video_path}")
            return False

        decoder = None
        player = None
        try:
            decoder = video.Decoder(video_path)
            sample_rate, channel = self._get_audio_params(decoder)
            player = audio.Player(
                sample_rate=sample_rate,
                channel=channel
            )
            player.volume(self._volume)

            print(f"[播放器] 开始播放: {video_path}")
            while not app.need_exit():
                ctx = decoder.decode()
                if not ctx:
                    break

                if self._is_video_ctx(ctx):
                    img = self._get_ctx_image(ctx)
                    if img:
                        self._disp.show(img, fit=image.Fit.FIT_CONTAIN)
                        delay_ms = max(1, int(self._get_ctx_duration_us(ctx) / 1000))
                        time.sleep_ms(delay_ms)
                elif self._is_audio_ctx(ctx):
                    pcm = self._get_ctx_pcm(ctx)
                    if pcm:
                        player.play(pcm)

            print("[播放器] 播放结束")
            return True

        except Exception as e:
            print(f"[播放器] 播放失败: {e}")
            return False
        finally:
            try:
                if decoder:
                    decoder.close()
            except Exception:
                pass
            try:
                if player:
                    player.finish()
            except Exception:
                pass

    def _get_audio_params(self, decoder):
        """读取解码器音频参数，失败时使用录制默认值"""
        sample_rate = 16000
        channel = 1
        try:
            if hasattr(decoder, "audio_sample_rate"):
                sample_rate = decoder.audio_sample_rate() or sample_rate
        except Exception:
            pass
        try:
            if hasattr(decoder, "audio_channels"):
                channel = decoder.audio_channels() or channel
        except Exception:
            pass
        return sample_rate, channel

    def _get_ctx_image(self, ctx):
        """兼容不同固件的视频帧接口"""
        if hasattr(ctx, "image"):
            return ctx.image()
        if hasattr(ctx, "get_image"):
            return ctx.get_image()
        return None

    def _get_ctx_pcm(self, ctx):
        """兼容不同固件的音频 PCM 接口"""
        if hasattr(ctx, "get_pcm"):
            return ctx.get_pcm()
        if hasattr(ctx, "pcm"):
            return ctx.pcm()
        return None

    def _get_ctx_duration_us(self, ctx):
        """获取帧持续时间"""
        try:
            if hasattr(ctx, "duration_us"):
                return ctx.duration_us() or 40000
        except Exception:
            pass
        return 40000

    def _get_ctx_media_name(self, ctx):
        """读取媒体类型名称用于兼容判断"""
        try:
            media_type = ctx.media_type()
            return str(media_type)
        except Exception:
            return ""

    def _is_video_ctx(self, ctx):
        """判断当前解码上下文是否为视频帧"""
        try:
            if hasattr(video, "MediaType"):
                return ctx.media_type() == video.MediaType.MEDIA_TYPE_VIDEO
        except Exception:
            pass
        return "VIDEO" in self._get_ctx_media_name(ctx).upper()

    def _is_audio_ctx(self, ctx):
        """判断当前解码上下文是否为音频帧"""
        try:
            if hasattr(video, "MediaType"):
                return ctx.media_type() == video.MediaType.MEDIA_TYPE_AUDIO
        except Exception:
            pass
        return "AUDIO" in self._get_ctx_media_name(ctx).upper()
