"""
MaixCAM2 人脸识别智能系统 - 推流管理模块

功能：
- HTTP JPEG 视频推流（支持推流处理后的画面）
- RTSP 视频推流（原始画面，用于监控）
- 推流启停控制
- 推流地址管理
- 网页端录制/截图/下载功能

使用方法：
- HTTP推流：通过浏览器访问推流地址查看实时画面
- RTSP推流：通过VLC/ffplay播放RTSP流
"""

from maix import http, network


class StreamManager:
    """
    推流管理器

    功能：
    - 管理 HTTP JPEG 流服务器
    - 控制推流启停
    - 获取推流地址
    - 推流带标注的人脸识别画面
    - 网页端支持录制视频、截图、下载
    """

    def __init__(self, jpeg_quality=75):
        """
        初始化推流管理器

        参数：
            jpeg_quality: JPEG 编码质量 (1-100)，默认 75
        """
        self._server = None
        self._is_streaming = False
        self._stream_url = ""
        self._jpeg_quality = jpeg_quality

        # 自定义网页界面（增强版 - 支持录制/截图/下载）
        self._html = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MaixCAM2 人脸识别系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            background: #0f0f1a;
            color: #e0e0e0;
            min-height: 100vh;
        }
        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 16px;
        }

        /* ========== 头部 ========== */
        .header {
            text-align: center;
            padding: 24px 16px;
            background: linear-gradient(135deg, #1a1a3e 0%, #0d1b2a 100%);
            border-radius: 16px;
            margin-bottom: 16px;
            border: 1px solid rgba(99, 102, 241, 0.3);
        }
        .logo { font-size: 42px; margin-bottom: 6px; }
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #818cf8, #6366f1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 4px;
        }
        .header p { color: #94a3b8; font-size: 13px; }

        /* ========== 视频卡片 ========== */
        .video-card {
            background: #1a1a2e;
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid rgba(99, 102, 241, 0.2);
            box-shadow: 0 4px 24px rgba(0,0,0,0.4);
        }
        .video-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: rgba(99, 102, 241, 0.1);
            border-bottom: 1px solid rgba(99, 102, 241, 0.2);
        }
        .video-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 14px;
        }
        .live-badge {
            background: #ef4444;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }

        /* 视频区域 */
        .video-wrapper {
            position: relative;
            background: #000;
            line-height: 0;
        }
        .video-wrapper img {
            display: block;
            width: 100%;
            height: auto;
            min-height: 240px;
            image-rendering: -webkit-optimize-contrast;
        }
        /* 隐藏的 canvas 用于截图/录制 */
        #captureCanvas { display: none; }

        /* 录制指示器 */
        .rec-indicator {
            position: absolute;
            top: 12px;
            right: 12px;
            background: rgba(239, 68, 68, 0.9);
            color: #fff;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            display: none;
            align-items: center;
            gap: 6px;
            backdrop-filter: blur(4px);
        }
        .rec-indicator.active { display: flex; }
        .rec-dot {
            width: 8px; height: 8px;
            background: #fff;
            border-radius: 50%;
            animation: blink 1s infinite;
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        /* ========== 控制按钮栏 ========== */
        .controls {
            display: flex;
            gap: 10px;
            padding: 14px 16px;
            background: rgba(15, 15, 26, 0.6);
            border-top: 1px solid rgba(99, 102, 241, 0.15);
            flex-wrap: wrap;
            justify-content: center;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
        }
        .btn:active { transform: scale(0.95); }
        .btn-record {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: #fff;
        }
        .btn-record.recording {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .btn-screenshot {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
        }
        .btn-download {
            background: linear-gradient(135deg, #10b981, #059669);
            color: #fff;
        }
        .btn-download:disabled {
            background: #374151;
            color: #6b7280;
            cursor: not-allowed;
        }
        .btn-clear {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            color: #fff;
        }

        /* ========== 状态栏 ========== */
        .status-bar {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            padding: 16px;
            background: #1a1a2e;
            border-radius: 12px;
            margin-top: 16px;
            border: 1px solid rgba(99, 102, 241, 0.2);
        }
        .status-item { text-align: center; }
        .status-icon { font-size: 22px; margin-bottom: 4px; }
        .status-label { font-size: 11px; color: #94a3b8; margin-bottom: 2px; }
        .status-value { font-size: 14px; font-weight: 600; color: #818cf8; }

        /* ========== 录制文件列表 ========== */
        .recordings-section {
            background: #1a1a2e;
            border-radius: 12px;
            margin-top: 16px;
            border: 1px solid rgba(99, 102, 241, 0.2);
            overflow: hidden;
        }
        .recordings-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: rgba(99, 102, 241, 0.08);
            border-bottom: 1px solid rgba(99, 102, 241, 0.15);
            font-weight: 600;
            font-size: 14px;
        }
        .recordings-count {
            background: rgba(99, 102, 241, 0.2);
            color: #818cf8;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
        }
        .recordings-list {
            max-height: 240px;
            overflow-y: auto;
            padding: 8px;
        }
        .recordings-list::-webkit-scrollbar { width: 6px; }
        .recordings-list::-webkit-scrollbar-track { background: transparent; }
        .recordings-list::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.3);
            border-radius: 3px;
        }
        .recording-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 12px;
            background: rgba(255,255,255,0.03);
            border-radius: 8px;
            margin-bottom: 6px;
            transition: background 0.2s;
        }
        .recording-item:hover { background: rgba(99, 102, 241, 0.1); }
        .recording-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            min-width: 0;
        }
        .recording-icon { font-size: 20px; flex-shrink: 0; }
        .recording-name {
            font-size: 12px;
            color: #cbd5e1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .recording-meta {
            font-size: 11px;
            color: #64748b;
            margin-top: 2px;
        }
        .recording-actions {
            display: flex;
            gap: 6px;
            flex-shrink: 0;
        }
        .btn-sm {
            padding: 5px 10px;
            font-size: 11px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-family: inherit;
            transition: all 0.2s;
        }
        .btn-sm:active { transform: scale(0.9); }
        .btn-play { background: #3b82f6; color: #fff; }
        .btn-delete { background: #ef4444; color: #fff; }
        .empty-tip {
            text-align: center;
            padding: 30px;
            color: #64748b;
            font-size: 13px;
        }
        .empty-tip .icon { font-size: 36px; margin-bottom: 8px; }

        /* ========== 预览弹窗 ========== */
        .modal-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            padding: 20px;
        }
        .modal-overlay.active { display: flex; }
        .modal-content {
            background: #1a1a2e;
            border-radius: 16px;
            overflow: hidden;
            max-width: 800px;
            width: 100%;
            border: 1px solid rgba(99, 102, 241, 0.3);
        }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: rgba(99, 102, 241, 0.1);
            border-bottom: 1px solid rgba(99, 102, 241, 0.2);
        }
        .modal-title { font-weight: 600; font-size: 14px; }
        .btn-close {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 20px;
            cursor: pointer;
            padding: 4px;
        }
        .modal-body { padding: 16px; }
        .modal-body video {
            width: 100%;
            border-radius: 8px;
            background: #000;
        }
        .modal-body img {
            width: 100%;
            border-radius: 8px;
        }

        /* ========== 页脚 ========== */
        .footer {
            text-align: center;
            padding: 16px;
            color: #475569;
            font-size: 11px;
            margin-top: 16px;
        }

        /* ========== Toast 提示 ========== */
        .toast {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%) translateY(-100px);
            background: rgba(30, 30, 50, 0.95);
            color: #e0e0e0;
            padding: 10px 20px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 500;
            z-index: 2000;
            transition: transform 0.3s ease;
            border: 1px solid rgba(99, 102, 241, 0.3);
            backdrop-filter: blur(8px);
        }
        .toast.show { transform: translateX(-50%) translateY(0); }

        /* ========== 响应式 ========== */
        @media (max-width: 600px) {
            .container { padding: 10px; }
            .header h1 { font-size: 20px; }
            .header p { font-size: 12px; }
            .status-bar { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .controls { gap: 8px; }
            .btn { padding: 8px 14px; font-size: 12px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 头部 -->
        <div class="header">
            <div class="logo">🤖</div>
            <h1>MaixCAM2 人脸识别系统</h1>
            <p>实时视频流 · 智能人脸识别 · 视频录制</p>
        </div>

        <!-- 视频卡片 -->
        <div class="video-card">
            <div class="video-header">
                <div class="video-title">
                    <span>📹</span>
                    <span>实时监控画面</span>
                </div>
                <span class="live-badge">● LIVE</span>
            </div>
            <div class="video-wrapper">
                <img src="/stream" alt="Video Stream" id="stream" crossorigin="anonymous">
                <div class="rec-indicator" id="recIndicator">
                    <span class="rec-dot"></span>
                    <span>REC </span><span id="recTime">00:00</span>
                </div>
            </div>
            <canvas id="captureCanvas"></canvas>
            <div class="controls">
                <button class="btn btn-record" id="btnRecord" onclick="toggleRecord()">
                    <span id="recordIcon">⏺</span>
                    <span id="recordText">开始录制</span>
                </button>
                <button class="btn btn-screenshot" onclick="takeScreenshot()">
                    📸 截图
                </button>
                <button class="btn btn-download" id="btnDownload" onclick="downloadRecording()" disabled>
                    💾 下载录制
                </button>
                <button class="btn btn-clear" onclick="clearRecordings()">
                    🗑️ 清空
                </button>
            </div>
        </div>

        <!-- 状态栏 -->
        <div class="status-bar">
            <div class="status-item">
                <div class="status-icon">🎯</div>
                <div class="status-label">识别状态</div>
                <div class="status-value" id="detectStatus">待机中</div>
            </div>
            <div class="status-item">
                <div class="status-icon">👤</div>
                <div class="status-label">人脸数量</div>
                <div class="status-value" id="faceCount">0</div>
            </div>
            <div class="status-item">
                <div class="status-icon">⏱️</div>
                <div class="status-label">运行时间</div>
                <div class="status-value" id="uptime">0:00</div>
            </div>
            <div class="status-item">
                <div class="status-icon">📡</div>
                <div class="status-label">连接状态</div>
                <div class="status-value" id="connStatus" style="color:#22c55e">正常</div>
            </div>
        </div>

        <!-- 录制文件列表 -->
        <div class="recordings-section">
            <div class="recordings-header">
                <span>📁 本地录制文件</span>
                <span class="recordings-count" id="recCount">0</span>
            </div>
            <div class="recordings-list" id="recordingsList">
                <div class="empty-tip">
                    <div class="icon">🎬</div>
                    <div>暂无录制文件</div>
                    <div style="margin-top:4px;font-size:11px">点击"开始录制"按钮录制视频</div>
                </div>
            </div>
        </div>

        <!-- 页脚 -->
        <div class="footer">
            <p>MaixCAM2 Face Recognition System v2.0 · 网页端录制版</p>
        </div>
    </div>

    <!-- 预览弹窗 -->
    <div class="modal-overlay" id="previewModal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="previewTitle">预览</span>
                <button class="btn-close" onclick="closePreview()">✕</button>
            </div>
            <div class="modal-body" id="previewBody"></div>
        </div>
    </div>

    <!-- Toast 提示 -->
    <div class="toast" id="toast"></div>

    <script>
    // ==================== 状态变量 ====================
    let isRecording = false;
    let mediaRecorder = null;
    let recordedChunks = [];
    let recordingStartTime = 0;
    let recTimerInterval = null;
    let recordings = [];  // {name, blob, url, size, duration, timestamp}
    let lastRecordedBlob = null;

    // ==================== 初始化 ====================
    const streamImg = document.getElementById('stream');
    const canvas = document.getElementById('captureCanvas');
    const ctx = canvas.getContext('2d');

    // 当图片加载后同步 canvas 尺寸
    streamImg.onload = function() {
        canvas.width = this.naturalWidth || this.width;
        canvas.height = this.naturalHeight || this.height;
    };

    // 图片加载错误处理
    streamImg.onerror = function() {
        this.src = 'data:image/svg+xml,' + encodeURIComponent(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">' +
            '<rect fill="#1a1a2e" width="400" height="300"/>' +
            '<text fill="#818cf8" font-family="Arial" font-size="18" x="50%" y="50%" text-anchor="middle">等待视频流...</text></svg>'
        );
    };

    // ==================== 运行时间 ====================
    let uptimeSeconds = 0;
    setInterval(() => {
        uptimeSeconds++;
        const m = Math.floor(uptimeSeconds / 60);
        const s = uptimeSeconds % 60;
        document.getElementById('uptime').textContent =
            m + ':' + (s < 10 ? '0' : '') + s;
    }, 1000);

    // ==================== 工具函数 ====================
    function showToast(msg, duration) {
        duration = duration || 2000;
        const t = document.getElementById('toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), duration);
    }

    function formatSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    function formatDuration(ms) {
        const s = Math.floor(ms / 1000);
        const m = Math.floor(s / 60);
        const sec = s % 60;
        return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec;
    }

    function getTimestamp() {
        const now = new Date();
        return now.getFullYear() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0') + '_' +
            String(now.getHours()).padStart(2, '0') +
            String(now.getMinutes()).padStart(2, '0') +
            String(now.getSeconds()).padStart(2, '0');
    }

    // 将 MJPEG img 绘制到 canvas
    function drawToCanvas() {
        if (streamImg.naturalWidth > 0) {
            if (canvas.width !== streamImg.naturalWidth) {
                canvas.width = streamImg.naturalWidth;
                canvas.height = streamImg.naturalHeight;
            }
            ctx.drawImage(streamImg, 0, 0, canvas.width, canvas.height);
        }
    }

    // ==================== 录制功能 ====================
    function toggleRecord() {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    function startRecording() {
        try {
            // 先绘制一帧到 canvas 确保尺寸正确
            drawToCanvas();

            // 从 canvas 获取流
            const stream = canvas.captureStream(15); // 15fps

            // 选择编码格式
            let mimeType = 'video/webm;codecs=vp9';
            if (!MediaRecorder.isTypeSupported(mimeType)) {
                mimeType = 'video/webm;codecs=vp8';
                if (!MediaRecorder.isTypeSupported(mimeType)) {
                    mimeType = 'video/webm';
                    if (!MediaRecorder.isTypeSupported(mimeType)) {
                        mimeType = '';
                    }
                }
            }

            const options = { videoBitsPerSecond: 2500000 };
            if (mimeType) options.mimeType = mimeType;

            mediaRecorder = new MediaRecorder(stream, options);
            recordedChunks = [];

            mediaRecorder.ondataavailable = function(e) {
                if (e.data && e.data.size > 0) {
                    recordedChunks.push(e.data);
                }
            };

            mediaRecorder.onstop = function() {
                const blob = new Blob(recordedChunks, { type: 'video/webm' });
                lastRecordedBlob = blob;

                // 添加到录制列表
                const duration = Date.now() - recordingStartTime;
                const name = 'recording_' + getTimestamp() + '.webm';
                const rec = {
                    name: name,
                    blob: blob,
                    url: URL.createObjectURL(blob),
                    size: blob.size,
                    duration: duration,
                    timestamp: Date.now()
                };
                recordings.unshift(rec);

                // 启用下载按钮
                document.getElementById('btnDownload').disabled = false;

                // 更新列表
                updateRecordingsList();
                showToast('✅ 录制完成: ' + name);
            };

            // 开始录制
            mediaRecorder.start(100); // 每100ms收集一次数据
            isRecording = true;
            recordingStartTime = Date.now();

            // 更新 UI
            document.getElementById('btnRecord').classList.add('recording');
            document.getElementById('recordIcon').textContent = '⏹';
            document.getElementById('recordText').textContent = '停止录制';
            document.getElementById('recIndicator').classList.add('active');

            // 启动录制计时
            recTimerInterval = setInterval(() => {
                const elapsed = Date.now() - recordingStartTime;
                document.getElementById('recTime').textContent = formatDuration(elapsed);
            }, 200);

            // 持续绘制帧到 canvas（确保录制内容更新）
            startFrameCapture();

            showToast('🔴 开始录制');
        } catch (err) {
            console.error('录制启动失败:', err);
            showToast('❌ 录制启动失败: ' + err.message);
        }
    }

    let frameCaptureInterval = null;
    function startFrameCapture() {
        if (frameCaptureInterval) clearInterval(frameCaptureInterval);
        frameCaptureInterval = setInterval(() => {
            if (isRecording) drawToCanvas();
        }, 66); // ~15fps
    }

    function stopRecording() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
        isRecording = false;

        if (frameCaptureInterval) {
            clearInterval(frameCaptureInterval);
            frameCaptureInterval = null;
        }

        // 更新 UI
        document.getElementById('btnRecord').classList.remove('recording');
        document.getElementById('recordIcon').textContent = '⏺';
        document.getElementById('recordText').textContent = '开始录制';
        document.getElementById('recIndicator').classList.remove('active');

        if (recTimerInterval) {
            clearInterval(recTimerInterval);
            recTimerInterval = null;
        }
    }

    // ==================== 截图功能 ====================
    function takeScreenshot() {
        drawToCanvas();

        canvas.toBlob(function(blob) {
            if (!blob) {
                showToast('❌ 截图失败');
                return;
            }
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'screenshot_' + getTimestamp() + '.png';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('📸 截图已保存');
        }, 'image/png');
    }

    // ==================== 下载录制 ====================
    function downloadRecording() {
        if (recordings.length === 0) {
            showToast('⚠️ 没有可下载的录制');
            return;
        }
        // 下载最新的录制
        const rec = recordings[0];
        const a = document.createElement('a');
        a.href = rec.url;
        a.download = rec.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showToast('💾 下载: ' + rec.name);
    }

    // ==================== 录制列表管理 ====================
    function updateRecordingsList() {
        const list = document.getElementById('recordingsList');
        const count = document.getElementById('recCount');
        count.textContent = recordings.length;

        if (recordings.length === 0) {
            list.innerHTML = '<div class="empty-tip">' +
                '<div class="icon">🎬</div>' +
                '<div>暂无录制文件</div>' +
                '<div style="margin-top:4px;font-size:11px">点击"开始录制"按钮录制视频</div>' +
                '</div>';
            return;
        }

        let html = '';
        recordings.forEach((rec, idx) => {
            html += '<div class="recording-item">' +
                '<div class="recording-info">' +
                '<span class="recording-icon">🎬</span>' +
                '<div>' +
                '<div class="recording-name">' + rec.name + '</div>' +
                '<div class="recording-meta">' + formatSize(rec.size) +
                ' · ' + formatDuration(rec.duration) + '</div>' +
                '</div></div>' +
                '<div class="recording-actions">' +
                '<button class="btn-sm btn-play" onclick="playRecording(' + idx + ')">▶ 播放</button>' +
                '<button class="btn-sm btn-delete" onclick="deleteRecording(' + idx + ')">✕</button>' +
                '</div></div>';
        });
        list.innerHTML = html;
    }

    function playRecording(idx) {
        const rec = recordings[idx];
        if (!rec) return;

        const modal = document.getElementById('previewModal');
        const body = document.getElementById('previewBody');
        const title = document.getElementById('previewTitle');

        title.textContent = '🎬 ' + rec.name;
        body.innerHTML = '<video controls autoplay style="max-height:60vh">' +
            '<source src="' + rec.url + '" type="video/webm">' +
            '您的浏览器不支持播放此视频</video>';
        modal.classList.add('active');
    }

    function deleteRecording(idx) {
        const rec = recordings[idx];
        if (!rec) return;
        URL.revokeObjectURL(rec.url);
        recordings.splice(idx, 1);
        updateRecordingsList();
        if (recordings.length === 0) {
            document.getElementById('btnDownload').disabled = true;
            lastRecordedBlob = null;
        }
        showToast('🗑️ 已删除');
    }

    function clearRecordings() {
        if (recordings.length === 0) return;
        if (!confirm('确定要清空所有录制文件吗？')) return;
        recordings.forEach(rec => URL.revokeObjectURL(rec.url));
        recordings = [];
        lastRecordedBlob = null;
        document.getElementById('btnDownload').disabled = true;
        updateRecordingsList();
        showToast('🗑️ 已清空所有录制');
    }

    // ==================== 预览弹窗 ====================
    function closePreview() {
        const modal = document.getElementById('previewModal');
        const body = document.getElementById('previewBody');
        modal.classList.remove('active');
        // 停止视频播放
        const video = body.querySelector('video');
        if (video) { video.pause(); video.src = ''; }
        body.innerHTML = '';
    }

    // 点击遮罩关闭
    document.getElementById('previewModal').addEventListener('click', function(e) {
        if (e.target === this) closePreview();
    });

    // ESC 关闭
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closePreview();
    });

    // ==================== 连接状态监测 ====================
    let reconnectTimer = null;
    streamImg.addEventListener('error', function() {
        document.getElementById('connStatus').textContent = '断开';
        document.getElementById('connStatus').style.color = '#ef4444';
        if (!reconnectTimer) {
            reconnectTimer = setInterval(() => {
                streamImg.src = '/stream?' + Date.now();
            }, 3000);
        }
    });

    streamImg.addEventListener('load', function() {
        document.getElementById('connStatus').textContent = '正常';
        document.getElementById('connStatus').style.color = '#22c55e';
        if (reconnectTimer) {
            clearInterval(reconnectTimer);
            reconnectTimer = null;
        }
    });
    </script>
</body>
</html>"""

        print("[推流] 推流管理器初始化完成")

    def _get_local_ip(self):
        """
        获取设备的本地 IP 地址

        返回：
            IP 地址字符串
        """
        try:
            w = network.wifi.Wifi()
            ip = w.get_ip()
            if ip and ip != "0.0.0.0":
                return ip
        except Exception as e:
            print(f"[推流] 获取 IP 失败: {e}")
        return "0.0.0.0"

    def start(self):
        """
        启动 HTTP JPEG 推流

        返回：
            True: 启动成功
            False: 启动失败
        """
        if self._is_streaming:
            print("[推流] 已在推流中")
            return True

        try:
            # 创建 HTTP JPEG 流服务器
            self._server = http.JpegStreamer()

            # 设置网页界面
            self._server.set_html(self._html)

            # 启动服务器
            self._server.start()

            # 获取推流地址（使用真实 IP）
            port = self._server.port()
            local_ip = self._get_local_ip()
            self._stream_url = f"http://{local_ip}:{port}"

            # 更新状态
            self._is_streaming = True

            print(f"[推流] HTTP 推流已启动")
            print(f"[推流] 推流地址: {self._stream_url}")
            print(f"[推流] 使用浏览器打开此地址查看")
            print(f"[推流] 支持功能: 录制视频 / 截图 / 下载")

            return True

        except Exception as e:
            print(f"[推流] 启动失败: {e}")
            self._cleanup()
            return False

    def write(self, img):
        """
        写入一帧图像进行推流

        参数：
            img: MaixPy Image 对象（带标注的画面）

        返回：
            True: 写入成功
            False: 写入失败或未推流
        """
        if not self._is_streaming or self._server is None:
            return False

        try:
            # 使用可配置的 JPEG 质量
            jpeg_img = img.to_jpeg(quality=self._jpeg_quality)
            self._server.write(jpeg_img)
            return True
        except Exception as e:
            # 如果转换失败，直接推流原始图像
            try:
                self._server.write(img)
            except:
                pass
            return False

    def stop(self):
        """
        停止 HTTP 推流

        返回：
            True: 停止成功
            False: 停止失败
        """
        if not self._is_streaming:
            return True

        try:
            self._cleanup()
            print("[推流] HTTP 推流已停止")
            return True

        except Exception as e:
            print(f"[推流] 停止失败: {e}")
            return False

    def _cleanup(self):
        """
        清理推流资源
        """
        self._server = None
        self._is_streaming = False
        self._stream_url = ""

    def is_streaming(self):
        """
        检查是否正在推流

        返回：
            True: 正在推流
            False: 未推流
        """
        return self._is_streaming

    def get_stream_url(self):
        """
        获取推流地址

        返回：
            HTTP 地址字符串，未推流时返回空字符串
        """
        return self._stream_url

    def destroy(self):
        """
        销毁推流管理器，释放资源
        """
        self.stop()
        print("[推流] 推流管理器已销毁")


class RtspStreamManager:
    """
    RTSP推流管理器

    功能：
    - 管理 RTSP 视频流服务器
    - 推流未经处理的原始画面（用于监控）
    - 支持 VLC/ffplay 播放

    注意事项：
    - RTSP模块只支持NV21格式（FMT_YVU420SP）
    - 绑定摄像头后，摄像头对象不能再被独立使用
    - RTSP服务启动后无法停止
    """

    def __init__(self):
        """
        初始化RTSP推流管理器
        """
        self._server = None
        self._cam = None
        self._audio_recorder = None
        self._is_streaming = False
        self._rtsp_url = ""

        print("[RTSP] RTSP推流管理器初始化完成")

    def _get_local_ip(self):
        """
        获取设备的本地 IP 地址

        返回：
            IP 地址字符串
        """
        try:
            w = network.wifi.Wifi()
            ip = w.get_ip()
            if ip and ip != "0.0.0.0":
                return ip
        except Exception as e:
            print(f"[RTSP] 获取 IP 失败: {e}")
        return "0.0.0.0"

    def start(self, width=640, height=480, enable_audio=True):
        """
        启动RTSP推流

        参数：
            width: 视频宽度
            height: 视频高度
            enable_audio: 是否启用音频推流

        返回：
            True: 启动成功
            False: 启动失败
        """
        if self._is_streaming:
            print("[RTSP] 已在推流中")
            return True

        try:
            from maix import rtsp, camera, image, audio

            # 创建独立的摄像头实例（YVU420SP格式）
            print(f"[RTSP] 初始化摄像头 ({width}x{height}, YVU420SP)...")
            self._cam = camera.Camera(width, height, image.Format.FMT_YVU420SP)

            # 创建RTSP服务器
            print("[RTSP] 创建RTSP服务器...")
            self._server = rtsp.Rtsp()

            # 绑定摄像头
            self._server.bind_camera(self._cam)

            # 绑定音频录制器（如果启用）
            if enable_audio:
                try:
                    print("[RTSP] 初始化音频录制器...")
                    self._audio_recorder = audio.Recorder()
                    self._server.bind_audio_recorder(self._audio_recorder)
                    print("[RTSP] 音频推流已启用")
                except Exception as e:
                    print(f"[RTSP] 音频初始化失败: {e}")
                    self._audio_recorder = None

            # 启动推流
            self._server.start()

            # 获取推流地址（从服务器获取，而不是自行拼接）
            self._rtsp_url = self._server.get_url()

            # 如果获取的地址包含0.0.0.0，尝试用真实IP替换
            if "0.0.0.0" in self._rtsp_url:
                real_ip = self._get_local_ip()
                if real_ip != "0.0.0.0":
                    self._rtsp_url = self._rtsp_url.replace("0.0.0.0", real_ip)

            # 更新状态
            self._is_streaming = True

            print("[RTSP] RTSP推流已启动")
            print(f"[RTSP] 播放地址: {self._rtsp_url}")
            print(f"[RTSP] VLC播放命令: vlc {self._rtsp_url}")
            print(f"[RTSP] ffplay播放命令: ffplay {self._rtsp_url}")

            return True

        except Exception as e:
            print(f"[RTSP] 启动失败: {e}")
            import traceback
            traceback.print_exc()
            self._cleanup()
            return False

    def is_streaming(self):
        """
        检查是否正在推流

        返回：
            True: 正在推流
            False: 未推流
        """
        return self._is_streaming

    def get_url(self):
        """
        获取RTSP推流地址

        返回：
            RTSP 地址字符串，未推流时返回空字符串
        """
        return self._rtsp_url

    def _cleanup(self):
        """
        清理推流资源
        """
        # 注意：RTSP没有stop方法，只能销毁引用
        self._audio_recorder = None
        self._cam = None
        self._server = None
        self._is_streaming = False
        self._rtsp_url = ""

    def destroy(self):
        """
        销毁RTSP推流管理器，释放资源
        """
        self._cleanup()
        print("[RTSP] RTSP推流管理器已销毁")
